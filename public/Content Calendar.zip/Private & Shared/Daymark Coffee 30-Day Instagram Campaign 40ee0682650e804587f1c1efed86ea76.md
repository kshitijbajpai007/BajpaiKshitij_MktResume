# Daymark Coffee: 30-Day Instagram Campaign

[Content Calendar](Daymark%20Coffee%2030-Day%20Instagram%20Campaign/Content%20Calendar%2040ee0682650e80d2ac81e489d85d6447.csv)

Content strategy and editorial calendar · Concept brand · Instagram-first

Campaign tagline: Sip your everyday ritual the way its supposed to.

## **1. Campaign foundation**

| **Parameter** | **Decision** |
| --- | --- |
| Brand | Daymark Coffee |
| Industry | Specialty coffee / F&B |
| Market | International urban market |
| Platform | Instagram |
| Duration | 30 days |
| Primary goal | Local awareness and footfall |
| Secondary goal | Community and repeat visits |
| Brand personality | Thoughtful, contemporary, welcoming |

**The problem:** There are hundreds of cafés selling coffee. Daymark needs to give people a reason to discover it, choose it and keep coming back.

**The proposition:** Make Daymark part of your everyday routine.

## **. Content mix**

| **Format** | **Volume** | **Role** |
| --- | --- | --- |
| Reels | 12 | Reach and discovery |
| Carousels | 6 | Saves and education |
| Statics | 2 | Brand statements |
| Stories | Daily, 2–4 frames | Interaction, research and footfall |

Cadence: 4–5 feed posts per week (20 across the month), with Stories running every day. Days marked as Stories in the calendar are Stories-led days with no feed post.

## **3. Content pillars**

Three pillars give the month a rhythm. Each weekday has a default pillar, so the audience learns what to expect and the team always knows what to make next.

| **Pillar** | **What it covers** | **Share of month** |
| --- | --- | --- |
| **The Ritual** | People, community, humour, UGC. The moments around the coffee. | 9 days (30%) |
| **The Craft** | Education, expertise, behind the scenes, the team. How and why we do it. | 9 days (30%) |
| **The Cup** | Product-led content, offers, social proof. The reason to walk in. | 12 days (40%) |

[Weekly Posting Plan](Daymark%20Coffee%2030-Day%20Instagram%20Campaign/Weekly%20Posting%20Plan%2040ee0682650e8068a177fa208da5755f.md)