# Before The Doors Open

Status: Idea
Publish date: November 14, 2026
Content type: Reel
Pillar: Craft
Film date: November 14, 2026

## Content overview

Show the people and preparation behind the café before opening.

## ToDos

- [ ]  20–25-second pre-opening POV: lights on, grinder dial-in, first shot tasted, doors open.

## Notes

- **3-second hook:** “The café you love starts at 5:45am.”
- **Caption:** Before the first customer, there's a first shot. We taste every morning's espresso before we open. See you when the doors do.

## Supporting files

[](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)