# First Sip Reactions

Status: Idea
Publish date: November 17, 2026
Content type: Reel
Pillar: Cup
Film date: November 17, 2026

## Content overview

Collect user-generated content and build social proof.

## ToDos

- [ ]  Stitch together customer-filmed first sips with reaction text overlays.
- [ ]  Obtain permission before using customer footage.

## Notes

- **3-second hook:** “Watch the first sip.”
- **Caption:** First sips, unscripted. Come make yours. Tag #MyDaymarkRitual.

## Supporting files

[](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)