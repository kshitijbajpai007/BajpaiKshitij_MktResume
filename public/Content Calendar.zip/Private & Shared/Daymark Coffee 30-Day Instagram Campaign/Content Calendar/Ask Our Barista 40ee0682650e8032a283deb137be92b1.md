# Ask Our Barista

Status: Idea
Publish date: November 16, 2026
Content type: Story
Pillar: Craft
Film date: November 16, 2026

## Content overview

Invite questions, build engagement, and demonstrate barista expertise.

## ToDos

- [ ]  Add a question box: “Ask our barista anything.”
- [ ]  Film answers across the following frames.

## Notes

- **3-second hook:** “Ask our barista anything.”
- **Caption:** Closing frame: “The best questions get a full answer on the feed.”

## Supporting files

[](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)