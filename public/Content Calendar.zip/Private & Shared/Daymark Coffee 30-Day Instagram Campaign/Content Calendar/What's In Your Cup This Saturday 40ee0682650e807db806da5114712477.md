# What's In Your Cup This Saturday?

Status: Idea
Publish date: November 20, 2026
Content type: Story
Pillar: Cup
Film date: November 20, 2026

## Content overview

Collect customer-generated content and encourage sharing.

## ToDos

- [ ]  Prompt: “Share your Saturday order” with an Add Yours sticker.
- [ ]  Repost selected entries.

## Notes

- **3-second hook:** “What's in your cup this Saturday?”
- **Caption:** Closing frame: “Post it, tag us, and we'll share our favourites.”

## Supporting files

[](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)