# Your Month At Daymark

Status: Idea
Publish date: November 28, 2026
Content type: Story
Pillar: Craft
Film date: November 28, 2026

## Content overview

Recap the month and invite the community to shape what's next.

## ToDos

- [ ]  Share favourite moments and community shout-outs.
- [ ]  Run a poll asking what to add to the menu next.

## Notes

- **3-second hook:** “Your month at Daymark.”
- **Caption:** Closing frame: “What should we add next month?”

## Supporting files

[](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)