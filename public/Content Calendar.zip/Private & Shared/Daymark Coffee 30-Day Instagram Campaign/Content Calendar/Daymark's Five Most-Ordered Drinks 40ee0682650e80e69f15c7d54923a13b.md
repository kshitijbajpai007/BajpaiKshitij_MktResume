# Daymark's Five Most-Ordered Drinks

Status: Idea
Publish date: November 27, 2026
Content type: Carousel
Pillar: Cup
Film date: November 27, 2026

## Content overview

Drive conversion and saves with a ranked guide to the café's most-ordered drinks.

## ToDos

- [ ]  Six slides: cover, then the top five drinks ranked.
- [ ]  Give each drink a photo and one-line tasting note.

## Notes

- **3-second hook:** “The five most-ordered drinks at Daymark.”
- **Caption:** Ranked by you. Which one is your number one? Save this as your order list.

## Supporting files

[](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)