# Bring Your Coffee Date

Status: Idea
Publish date: November 25, 2026
Content type: Story
Pillar: Ritual
Film date: November 25, 2026

## Content overview

Remind viewers about the promotion and encourage word of mouth.

## ToDos

- [ ]  Add a countdown sticker and show a close-up of the Ritual Card.
- [ ]  Prompt viewers to tag their coffee date.

## Notes

- **3-second hook:** “Who's your coffee date this week?”
- **Caption:** Closing frame: “Bring someone. Get your first stamp.”

## Supporting files

[](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)