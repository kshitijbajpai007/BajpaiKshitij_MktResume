# The Right Coffee For Every Hour

Status: Idea
Publish date: November 22, 2026
Content type: Carousel
Pillar: Ritual
Film date: November 22, 2026

## Content overview

Give viewers an educational, saveable guide for choosing coffee throughout the day.

## ToDos

- [ ]  Five slides: cover plus morning, midday, afternoon, and evening.
- [ ]  Shift the colour softly across the slides.

## Notes

- **3-second hook:** “The right coffee for every hour.”
- **Caption:** What are you ordering at 8am versus 3pm? Save this guide and settle it once and for all.

## Supporting files

[](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)