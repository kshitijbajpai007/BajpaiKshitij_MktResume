# Three Pour-Over Tweaks

Status: Idea
Publish date: November 21, 2026
Content type: Reel
Pillar: Craft
Film date: November 21, 2026

## Content overview

Educate viewers and encourage shares with practical home-coffee advice.

## ToDos

- [ ]  Split-screen home pour-over before and after three tweaks: grind, water temperature, and ratio.

## Notes

- **3-second hook:** “Your home coffee is three tweaks from café quality.”
- **Caption:** Grind a little finer, use water just off the boil, and aim for 1:16. Try it this weekend and tell us how it went.

## Supporting files

[](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)