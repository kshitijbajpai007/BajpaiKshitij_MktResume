# The 30-Minute Coffee Break

Status: Idea
Publish date: November 4, 2026
Content type: Reel
Pillar: Ritual
Film date: November 4, 2026

## Content overview

Create a relatable, humorous reel designed for shares.

## ToDos

- [ ]  Show the progression: “just one coffee,” laptop opens, second drink, pastry, then dark outside.

## Notes

- **3-second hook:** “I'll only stay for 30 minutes.”
- **Caption:** The 30-minute coffee break that somehow becomes a lifestyle. Tag your favourite café-time accomplice.

## Supporting files

[](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)