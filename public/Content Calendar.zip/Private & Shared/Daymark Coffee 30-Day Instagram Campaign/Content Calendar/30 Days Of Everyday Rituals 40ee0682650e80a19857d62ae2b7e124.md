# 30 Days Of Everyday Rituals

Status: Idea
Publish date: November 29, 2026
Content type: Reel
Pillar: Ritual
Film date: November 29, 2026

## Content overview

Celebrate the brand and encourage shares with a month-end recap.

## ToDos

- [ ]  25-second montage of the month's best UGC and behind-the-scenes moments.
- [ ]  End on the logo.

## Notes

- **3-second hook:** “30 days of everyday rituals.”
- **Caption:** Thirty days, countless little moments. Thank you for making room for us. Your ritual is always welcome.

## Supporting files

[](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)