# Anatomy Of A Shot

Status: Idea
Publish date: November 9, 2026
Content type: Reel
Pillar: Craft
Film date: November 9, 2026

## Content overview

Establish coffee expertise by showing how an espresso shot is dialled in.

## ToDos

- [ ]  Film overhead espresso extraction with an on-screen timer.
- [ ]  Show the three beats: dose, time, yield.

## Notes

- **3-second hook:** “Great espresso is decided in about 30 seconds.”
- **Caption:** Dose, time, yield. Small numbers, big difference. This is how we pull every shot. Save it for your next coffee debate.

## Supporting files

[](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)