# Intro To Brand

Status: Idea
Publish date: November 1, 2026
Content type: Reel
Pillar: Ritual
Film date: November 1, 2026

## Content overview

Introduce the brand and the “everyday ritual” idea.

## ToDos

- [ ]  25-second sequence: morning light, espresso pour, friends laughing, reader at the window, barista serving, exterior and logo.

## Notes

- **3-second hook:** “Not every day needs to be extraordinary.”
- **Caption:** The best parts of a day aren't always the biggest. Your usual order, your favourite seat, a conversation that runs long. We're here for all of it. Welcome to Daymark.

## Supporting files

[](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)