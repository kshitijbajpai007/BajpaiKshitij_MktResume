# Coffee, Flat White, Latte & Cortado Guide

Status: Idea
Publish date: November 12, 2026
Content type: Carousel
Pillar: Cup
Film date: November 12, 2026

## Content overview

Educate the audience about espresso-and-milk drinks and create a saveable guide.

## ToDos

- [ ]  Six slides: cover, flat white, latte, cortado, cappuccino, and “how to choose.”
- [ ]  Use clean illustrated cups.

## Notes

- **3-second hook:** “Flat white, latte, cortado: the difference, finally.”
- **Caption:** Save this before your next order. Then tell us: what's yours?

## Supporting files

[](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)