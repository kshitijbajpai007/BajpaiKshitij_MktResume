# Week One Recap

Status: Idea
Publish date: November 7, 2026
Content type: Story
Pillar: Craft
Film date: November 7, 2026

## Content overview

Collect community feedback and continue the conversation after the first week.

## ToDos

- [ ]  Share behind-the-scenes highlights.
- [ ]  Feature the best coffee or food shot from the week.
- [ ]  Add a question sticker.

## Notes

- **3-second hook:** “Seven days, countless little moments.”
- **Caption:** Closing frame: “What's one thing you'd like to see next week?”

## Supporting files

[](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)