# Thank You, Daymark

Status: Idea
Publish date: November 30, 2026
Content type: Static
Pillar: Craft
Film date: November 30, 2026

## Content overview

Show gratitude and encourage retention with a team thank-you.

## ToDos

- [ ]  Team group portrait inside the café with a simple thank-you headline.

## Notes

- **3-second hook:** “Thank you for making room for us.”
- **Caption:** The whole team, one big thank you. Your Ritual Card is still waiting. See you tomorrow?

## Supporting files

[](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)