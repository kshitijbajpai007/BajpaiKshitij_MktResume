# My Daymark Ritual

Status: Idea
Publish date: November 15, 2026
Content type: Static
Pillar: Ritual
Film date: November 15, 2026

## Content overview

Reinforce brand identity and launch the community UGC hashtag.

## ToDos

- [ ]  Create a typographic poster over a window-light still life using the brand palette.

## Notes

- **3-second hook:** “Make room for your everyday ritual.”
- **Caption:** Tell us yours. Share your Daymark moment with #MyDaymarkRitual and we'll feature our favourites.

## Supporting files

[](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)