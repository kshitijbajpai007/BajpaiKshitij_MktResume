# Saturday At Daymark

Status: Idea
Publish date: November 13, 2026
Content type: Story
Pillar: Cup
Film date: November 13, 2026

## Content overview

Drive Saturday footfall with a timely look at the café.

## ToDos

- [ ]  Show what's pouring and the pastry of the day.
- [ ]  Capture the window seat and add a location sticker.

## Notes

- **3-second hook:** “Saturday plans? Start here.”
- **Caption:** Closing frame: “Open from [time]. Window seats are first come, first served.”

## Supporting files

[](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)