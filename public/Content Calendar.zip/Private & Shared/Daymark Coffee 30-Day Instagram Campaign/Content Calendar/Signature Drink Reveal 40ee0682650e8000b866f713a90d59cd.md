# Signature Drink Reveal

Status: Idea
Publish date: November 6, 2026
Content type: Reel
Pillar: Cup
Film date: November 6, 2026

## Content overview

Build product awareness and purchase consideration for the signature drink.

## ToDos

- [ ]  20-second sensory close-ups: finished drink, ice drop, espresso pour, milk, and garnish.

## Notes

- **3-second hook:** “Some introductions don't need many words.”
- **Caption:** Your usual order might have some competition. Meet the [Signature Drink], made for your next coffee break. Try it at Daymark.

## Supporting files

[](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)