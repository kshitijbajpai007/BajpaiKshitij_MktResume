# Order Personality

Status: Idea
Publish date: November 11, 2026
Content type: Reel
Pillar: Ritual
Film date: November 11, 2026

## Content overview

Use humour to encourage shares and help viewers recognise their coffee-order personality.

## ToDos

- [ ]  Barista “reads” customers from their orders: oat flat white, black americano, iced everything.
- [ ]  Use deadpan quick cuts.

## Notes

- **3-second hook:** “Your coffee order says more than you think.”
- **Caption:** We've been paying attention. Which one are you? Send this to the person who orders it.

## Supporting files

[](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)