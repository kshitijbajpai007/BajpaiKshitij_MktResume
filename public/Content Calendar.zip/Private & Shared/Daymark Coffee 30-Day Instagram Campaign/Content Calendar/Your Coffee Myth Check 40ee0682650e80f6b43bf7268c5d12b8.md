# Your Coffee Myth Check

Status: Idea
Publish date: November 23, 2026
Content type: Story
Pillar: Craft
Film date: November 23, 2026

## Content overview

Engage viewers with a myth-or-fact quiz about coffee.

## ToDos

- [ ]  Quiz: “Dark roast has more caffeine.”
- [ ]  Quiz: “Coffee dehydrates you.”
- [ ]  Reveal the answer after each question.

## Notes

- **3-second hook:** “Myth or fact? Dark roast has more caffeine.”
- **Caption:** Closing frame: “Got a coffee myth? Send it to us.”

## Supporting files

[](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)