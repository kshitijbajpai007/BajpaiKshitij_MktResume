# Build Your Coffee

Status: Idea
Publish date: November 5, 2026
Content type: Story
Pillar: Cup
Film date: November 5, 2026

## Content overview

Research drink preferences with a tap-through order builder that ends in a recommendation.

## ToDos

- [ ]  Intro frame, then poll on hot or iced.
- [ ]  Poll on strong or smooth.
- [ ]  Poll on sweet or unsweetened.
- [ ]  End with a drink recommendation.

## Notes

- **3-second hook:** “Let's build your perfect coffee.”
- **Caption:** Reveal frame: “We think we know what you should order next.”

## Supporting files

[](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)