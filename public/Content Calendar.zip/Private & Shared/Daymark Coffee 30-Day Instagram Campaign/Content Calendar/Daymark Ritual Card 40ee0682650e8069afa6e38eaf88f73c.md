# Daymark Ritual Card

Status: Idea
Publish date: November 24, 2026
Content type: Reel
Pillar: Cup
Film date: November 24, 2026

## Content overview

Promote the loyalty card and encourage repeat visits.

## ToDos

- [ ]  15-second stamp-card animation: stamp five cups; the sixth appears as “on us.”

## Notes

- **3-second hook:** “Your sixth coffee is on us.”
- **Caption:** Introducing the Daymark Ritual Card. Collect five stamps and the sixth coffee is on us. Ask at the counter. [Offer terms to be confirmed]

## Supporting files

[](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)