# Which Daymark Ritual Are You?

Status: Idea
Publish date: November 18, 2026
Content type: Carousel
Pillar: Ritual
Film date: November 18, 2026

## Content overview

Build community and relatability by showing familiar customer routines.

## ToDos

- [ ]  Six slides featuring five rituals: the 7:40 regular, window-seat reader, Friday catch-up, laptop sprint, and post-gym iced.

## Notes

- **3-second hook:** “The 7:40 regular. The window-seat reader. Which one are you?”
- **Caption:** Five rituals we see every week. Which one is yours? Share to Stories and tag us.

## Supporting files

[](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)