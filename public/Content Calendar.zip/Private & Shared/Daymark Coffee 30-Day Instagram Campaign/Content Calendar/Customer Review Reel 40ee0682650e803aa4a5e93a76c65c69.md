# Customer Review Reel

Status: Idea
Publish date: November 26, 2026
Content type: Reel
Pillar: Cup
Film date: November 26, 2026

## Content overview

Build social proof with real customer feedback.

## ToDos

- [ ]  Show genuine customer review quotes over café b-roll in quick cuts.
- [ ]  Use real reviews only.

## Notes

- **3-second hook:** “‘I came for the coffee. I stayed for four hours.’”
- **Caption:** Your words, not ours. Thank you. Come write the next one. [Use genuine reviews only]

## Supporting files

[](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)

[https://app.notion.com](https://app.notion.com)