# Weekly Posting Plan

| **Day** | **Pillar** | **Why this day** |
| --- | --- | --- |
| Mon | The Ritual | Sets the tone for the week with a relatable, human opener. |
| Tues | The Craft | Slower-read educational content and Q&A. |
| Wed | The Cup | Midweek product push. |
| Thu | The Ritual | Humour, shareable and tag-worthy content. |
| Fri | The Cup | Builds appetite ahead of the weekend. |
| Sat | The Cup | Peak footfall day: product and "come in now" content. |
| Sun | The Craft | Behind the scenes and home-brewing content for a slower day. |